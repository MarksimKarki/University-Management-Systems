package com.ums.models;

public class Admin {
	private final String name="admin";
	private final String password="123";
	public String getName() {
		return name;
	}
	public String getPassword() {
		return password;
	}
	
	
}
