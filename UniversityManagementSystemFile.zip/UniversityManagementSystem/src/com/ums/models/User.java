package com.ums.models;

public class User {
	private final String name="user";
	private final String password="123";
	public String getName() {
		return name;
	}
	public String getPassword() {
		return password;
	}
}
