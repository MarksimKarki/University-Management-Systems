package com.ums.services;

public interface Services {
	public void integrateStudentExam(String id);
	public void displayStudentInfo(String id);
	
}
